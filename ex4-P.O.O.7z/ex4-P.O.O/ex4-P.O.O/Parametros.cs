﻿public class Parametro
{
    public double Somar(double n1, double n2)
    {
        double resultado = n1 + n2;
        return resultado;
    }
    public double Subtrair(double n1, double n2)
    {
        double resultado = n1 + n2;
        return resultado;
    }

    public double Multiplicar(double n1, double n2)
    {
        double resultado = n1 + n2;
        return resultado;
    }
    public double Dividir(double n1, double n2)
    {
        double resultado = n1 + n2;
        return resultado;
    }



}

    


