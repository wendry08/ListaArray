﻿public class Hora
{
    public double HoraMin(double n)
    {
        return n * 60;
    }
    public double MinSeg(double n)
    {
        return n / 60;
    }
    public double SegMin(double n)
    {
        return n / 3600;
    }
}

   



