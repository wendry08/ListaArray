﻿public class Pessoas
{
    public string cpf;
    public string nome;
    public string email;

    public Pessoas(string nome, string cpf, string email)
    {
        this.nome = nome;
        this.email = email;
        this.cpf = cpf;
    }

    
}