﻿public class Gabarito
{
    
    char[] gabaritoCorreto = { 'A', 'C', 'D', 'E', 'A' };// char = armazena um caracter
   
    public char RespostaQuestao(int nQuestao)//
    {
        return this.gabaritoCorreto [nQuestao];
    }
  
}
