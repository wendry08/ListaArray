﻿using System;

public class Validacoes
{
    public static bool ValidarCPF(string cpf)
    {
        //remover traço do cpf
        cpf = cpf.Replace(".", "");
        cpf = cpf.Replace("-", "");

        int soma = 0;
        int sobra = 0;
        string digito;
        string CPF;
        int resultado = 0;

        //
        if (cpf.Length != 11)
        {

            return false;
        }
        CPF = cpf.Substring(0, 9);
        int[] multiplicacao = new int[9]{ 10,9,8,7,6,5,4,3,2};
        int[] multiplicacao2 = new int[10]{ 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 };

        for(int i = 0; i < cpf.Length -2; i++)
        {
            soma += int.Parse(cpf[i].ToString()) + multiplicacao[i];//parse converte para int
        }
        sobra = soma % 11;

        if(sobra < 2)
        {
            sobra = 0;
        }
        else
        {
            sobra = 11 - sobra;
        }
        digito = sobra.ToString();
        CPF = cpf + digito;

        for (int i = 0; i < cpf.Length - 1; i++)
        {
            soma += int.Parse(cpf[i].ToString()) * multiplicacao[i];
        }
        sobra = sobra % 11;

        if (sobra < 2)
        {
            sobra = 0;
        }
        else
        {
            sobra = 11 - sobra;
        }
        digito = digito + sobra.ToString();

        return true;
        Console.WriteLine("cpf valido");



    } 
}