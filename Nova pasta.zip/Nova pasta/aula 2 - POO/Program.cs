﻿Aluno aluno1 = new Aluno();
aluno1.nome = "elias";
aluno1.email = "email";
aluno1.nota1 = 8;
aluno1.nota2 = 9;

aluno1.CalcularMedia();

Aluno aluno2 = new Aluno();
aluno2.nome = "wendry";
aluno2.email = "email";
aluno2.nota1 = 4;
aluno2.nota2 = 7;

aluno2.CalcularMedia();

